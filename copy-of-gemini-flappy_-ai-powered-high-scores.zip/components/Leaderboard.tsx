
import React from 'react';
import { getLeaderboard } from '../services/storageService';

interface LeaderboardProps {
  onBack: () => void;
}

const Leaderboard: React.FC<LeaderboardProps> = ({ onBack }) => {
  const scores = getLeaderboard();

  return (
    <div className="p-6 bg-[#ded895] min-h-screen md:min-h-[500px] border-l-4 border-r-4 border-black">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold tracking-tighter drop-shadow-sm">HALL OF FAME</h2>
        <button 
          onClick={onBack}
          className="bg-red-500 text-white px-3 py-2 border-4 border-black text-[8px] shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] active:shadow-none font-bold"
        >
          BACK
        </button>
      </div>

      <div className="space-y-3">
        {scores.length === 0 ? (
          <div className="text-center text-[10px] py-20 text-gray-600 animate-pulse">NO LEGENDS YET...</div>
        ) : (
          scores.map((entry, index) => {
            const isGuest = entry.username.startsWith('GUEST_');
            return (
              <div 
                key={`${entry.username}-${index}`}
                className={`flex items-center justify-between p-3 border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] ${index === 0 ? 'bg-yellow-300' : 'bg-white'}`}
              >
                <div className="flex items-center gap-3">
                  <span className="text-[10px] font-bold w-6">{index + 1}.</span>
                  <div>
                    <div className="text-[10px] font-bold uppercase truncate max-w-[140px] flex items-center gap-2">
                      {entry.username}
                      {isGuest && <span className="text-[6px] bg-black text-white px-1 rounded">GUEST</span>}
                    </div>
                    <div className="text-[6px] text-gray-500 mt-1">{entry.date}</div>
                  </div>
                </div>
                <div className="text-xl font-bold">
                  {entry.score}
                </div>
              </div>
            );
          })
        )}
      </div>

      <div className="mt-12 p-4 bg-white/50 border-4 border-dashed border-black rounded text-[7px] text-center text-gray-800 leading-relaxed uppercase font-bold">
        GLOBAL HIGH RECORDS ARE SAVED LOCALLY. <br/>
        GUEST PROGRESS IS PERSISTENT UNTIL CLEARANCE.
      </div>
    </div>
  );
};

export default Leaderboard;
