
import React, { useEffect, useRef, useState, useCallback } from 'react';
import { User, Pipe, Difficulty } from '../types';
import { 
  CANVAS_WIDTH, 
  CANVAS_HEIGHT, 
  BIRD_SIZE,
  PIPE_WIDTH,
  DIFFICULTY_CONFIG
} from '../constants';
import { updateHighScore } from '../services/storageService';
import { getGeminiMessage } from '../services/geminiService';
import { audioService } from '../services/audioService';

interface GameCanvasProps {
  user: User;
  onScoreUpdate: () => void;
}

const GameCanvas: React.FC<GameCanvasProps> = ({ user, onScoreUpdate }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [isGameOver, setIsGameOver] = useState(false);
  const [isStarted, setIsStarted] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [difficulty, setDifficulty] = useState<Difficulty>(Difficulty.NORMAL);
  const [aiMessage, setAiMessage] = useState('CHOOSE MODE & FLAP!');
  const [loadingAi, setLoadingAi] = useState(false);

  const birdY = useRef(CANVAS_HEIGHT / 2);
  const birdVelocity = useRef(0);
  const pipes = useRef<Pipe[]>([]);
  const frameId = useRef<number>(0);

  const config = DIFFICULTY_CONFIG[difficulty];

  const initGame = useCallback(() => {
    birdY.current = CANVAS_HEIGHT / 2;
    birdVelocity.current = 0;
    pipes.current = [
      { x: CANVAS_WIDTH + 150, topHeight: 150 + Math.random() * 100, passed: false }
    ];
    setScore(0);
    setIsGameOver(false);
    setIsStarted(false);
    setIsPaused(false);
    setAiMessage('CHOOSE MODE & FLAP!');
  }, []);

  useEffect(() => {
    initGame();
  }, [initGame]);

  const handleDeath = useCallback(async (finalScore: number) => {
    if (isGameOver) return;
    setIsGameOver(true);
    audioService.playCrash();
    
    // Update personal best immediately
    updateHighScore(user.username, finalScore);
    onScoreUpdate();
    
    setLoadingAi(true);
    try {
      const msg = await getGeminiMessage(finalScore, user.username);
      setAiMessage(msg);
    } catch (e) {
      setAiMessage('RETRY? YOU CAN DO BETTER!');
    } finally {
      setLoadingAi(false);
    }
  }, [user.username, isGameOver, onScoreUpdate]);

  const jump = useCallback((e?: React.PointerEvent | React.MouseEvent | React.TouchEvent) => {
    if (e) e.stopPropagation();
    if (isPaused) return;
    
    if (isGameOver) {
      initGame();
      return;
    }
    
    if (!isStarted) {
      setIsStarted(true);
    }
    
    audioService.playJump();
    birdVelocity.current = config.jumpForce;
  }, [isStarted, isGameOver, isPaused, initGame, config.jumpForce]);

  const togglePause = (e: React.MouseEvent | React.PointerEvent) => {
    e.stopPropagation();
    if (isStarted && !isGameOver) {
      setIsPaused(!isPaused);
    }
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.code === 'ArrowUp') jump();
      if (e.code === 'KeyP' || e.code === 'Escape') setIsPaused(p => !p);
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [jump]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const draw = () => {
      // Background Clear
      ctx.fillStyle = '#4ec0ca';
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

      // Clouds
      ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
      [100, 300, 500].forEach((x, i) => {
        const offset = (Date.now() / 60 + i * 200) % (CANVAS_WIDTH + 100);
        ctx.beginPath();
        ctx.arc(CANVAS_WIDTH - offset, 120 + i * 40, 30, 0, Math.PI * 2);
        ctx.arc(CANVAS_WIDTH - offset + 30, 120 + i * 40, 40, 0, Math.PI * 2);
        ctx.arc(CANVAS_WIDTH - offset + 60, 120 + i * 40, 30, 0, Math.PI * 2);
        ctx.fill();
      });

      // Ground
      ctx.fillStyle = '#ded895';
      ctx.fillRect(0, CANVAS_HEIGHT - 50, CANVAS_WIDTH, 50);
      ctx.fillStyle = '#73bf2e';
      ctx.fillRect(0, CANVAS_HEIGHT - 50, CANVAS_WIDTH, 12);

      if (isStarted && !isGameOver && !isPaused) {
        birdVelocity.current += config.gravity;
        birdY.current += birdVelocity.current;

        // Ground Collision
        if (birdY.current + BIRD_SIZE / 2 > CANVAS_HEIGHT - 50) {
          handleDeath(score);
        }

        // Unlimited Flight (No ceiling death)
        if (birdY.current < -200) {
          birdY.current = -200;
          birdVelocity.current = 0;
        }

        pipes.current.forEach(pipe => {
          pipe.x -= config.pipeSpeed;

          const birdRect = {
            left: CANVAS_WIDTH / 4 - 12,
            right: CANVAS_WIDTH / 4 + 12,
            top: birdY.current - 10,
            bottom: birdY.current + 10
          };

          const topPipeRect = { left: pipe.x, right: pipe.x + PIPE_WIDTH, top: 0, bottom: pipe.topHeight };
          const bottomPipeRect = { left: pipe.x, right: pipe.x + PIPE_WIDTH, top: pipe.topHeight + config.pipeGap, bottom: CANVAS_HEIGHT };

          if (
            (birdRect.right > topPipeRect.left && birdRect.left < topPipeRect.right && birdRect.top < topPipeRect.bottom) ||
            (birdRect.right > bottomPipeRect.left && birdRect.left < bottomPipeRect.right && birdRect.bottom > bottomPipeRect.top)
          ) {
            handleDeath(score);
          }

          if (!pipe.passed && pipe.x + PIPE_WIDTH < CANVAS_WIDTH / 4) {
            pipe.passed = true;
            audioService.playScore();
            setScore(s => s + 1);
          }
        });

        if (pipes.current.length === 0 || pipes.current[pipes.current.length - 1].x < CANVAS_WIDTH - config.pipeSpacing) {
          pipes.current.push({
            x: CANVAS_WIDTH,
            topHeight: 100 + Math.random() * (CANVAS_HEIGHT - 380),
            passed: false
          });
        }

        if (pipes.current.length > 0 && pipes.current[0].x < -PIPE_WIDTH - 20) {
          pipes.current.shift();
        }
      }

      // Render Pipes
      pipes.current.forEach(pipe => {
        const gradient = ctx.createLinearGradient(pipe.x, 0, pipe.x + PIPE_WIDTH, 0);
        gradient.addColorStop(0, '#538f20');
        gradient.addColorStop(0.5, '#73bf2e');
        gradient.addColorStop(1, '#538f20');
        ctx.fillStyle = gradient;
        ctx.strokeStyle = '#000';
        ctx.lineWidth = 3;
        
        ctx.fillRect(pipe.x, 0, PIPE_WIDTH, pipe.topHeight);
        ctx.strokeRect(pipe.x, -5, PIPE_WIDTH, pipe.topHeight + 5);
        ctx.fillRect(pipe.x, pipe.topHeight + config.pipeGap, PIPE_WIDTH, CANVAS_HEIGHT - pipe.topHeight - config.pipeGap);
        ctx.strokeRect(pipe.x, pipe.topHeight + config.pipeGap, PIPE_WIDTH, CANVAS_HEIGHT - pipe.topHeight - config.pipeGap + 5);
        
        ctx.fillRect(pipe.x - 4, pipe.topHeight - 24, PIPE_WIDTH + 8, 24);
        ctx.strokeRect(pipe.x - 4, pipe.topHeight - 24, PIPE_WIDTH + 8, 24);
        ctx.fillRect(pipe.x - 4, pipe.topHeight + config.pipeGap, PIPE_WIDTH + 8, 24);
        ctx.strokeRect(pipe.x - 4, pipe.topHeight + config.pipeGap, PIPE_WIDTH + 8, 24);
      });

      // Render Bird
      ctx.save();
      ctx.translate(CANVAS_WIDTH / 4, birdY.current);
      ctx.rotate(Math.min(Math.PI / 3, Math.max(-Math.PI / 4, birdVelocity.current * 0.08)));
      
      ctx.fillStyle = '#f7d302';
      ctx.strokeStyle = '#000';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.ellipse(0, 0, 16, 13, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = 'white';
      ctx.beginPath();
      ctx.arc(8, -5, 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = 'black';
      ctx.beginPath();
      ctx.arc(10, -5, 2.5, 0, Math.PI * 2);
      ctx.fill();

      const wingWobble = (isStarted && !isPaused) ? Math.sin(Date.now() / 40) * 6 : 0;
      ctx.fillStyle = 'white';
      ctx.beginPath();
      ctx.ellipse(-8, 2, 9, 6 + wingWobble, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = '#f75b1c';
      ctx.beginPath();
      ctx.moveTo(14, -2); ctx.lineTo(24, 2); ctx.lineTo(14, 6); ctx.closePath();
      ctx.fill();
      ctx.stroke();

      ctx.restore();

      // Score Display
      ctx.fillStyle = 'white';
      ctx.strokeStyle = 'black';
      ctx.lineWidth = 6;
      ctx.font = '32px "Press Start 2P"';
      ctx.textAlign = 'center';
      ctx.strokeText(score.toString(), CANVAS_WIDTH / 2, 80);
      ctx.fillText(score.toString(), CANVAS_WIDTH / 2, 80);

      frameId.current = requestAnimationFrame(draw);
    };

    draw();
    return () => cancelAnimationFrame(frameId.current);
  }, [isStarted, isGameOver, isPaused, handleDeath, score, config]);

  return (
    <div 
      className="relative w-full h-full cursor-pointer select-none overflow-hidden touch-none" 
      onPointerDown={jump}
    >
      <canvas
        ref={canvasRef}
        width={CANVAS_WIDTH}
        height={CANVAS_HEIGHT}
        className="w-full h-full object-cover block"
      />

      {/* Pause Button */}
      {isStarted && !isGameOver && (
        <button 
          onPointerDown={togglePause}
          className="absolute top-4 right-4 z-50 bg-white/20 hover:bg-white/40 border-2 border-black w-10 h-10 flex items-center justify-center text-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:shadow-none"
        >
          <i className={`fas ${isPaused ? 'fa-play' : 'fa-pause'} text-xs`}></i>
        </button>
      )}

      {/* Start Overlay */}
      {!isStarted && !isGameOver && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/10 text-white p-4">
          <div className="bg-white/95 text-black p-6 border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] text-center">
             <div className="text-[12px] font-bold mb-4 uppercase tracking-tight">Difficulty Selection</div>
             
             <div className="grid grid-cols-3 gap-2 mb-6">
               {(Object.keys(Difficulty) as Array<keyof typeof Difficulty>).map(diffKey => {
                 const diffValue = Difficulty[diffKey];
                 const isSelected = difficulty === diffValue;
                 const colors = {
                   [Difficulty.EASY]: 'bg-green-400',
                   [Difficulty.NORMAL]: 'bg-yellow-400',
                   [Difficulty.HARD]: 'bg-red-400'
                 };
                 return (
                   <button
                    key={diffValue}
                    onPointerDown={(e) => { e.stopPropagation(); setDifficulty(diffValue); }}
                    className={`text-[7px] p-2 border-2 border-black font-bold shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:shadow-none ${isSelected ? colors[diffValue] + ' translate-x-1 translate-y-1 shadow-none' : 'bg-white'}`}
                   >
                     {diffValue}
                   </button>
                 );
               })}
             </div>

             <div className="text-[9px] leading-relaxed mb-4 opacity-70 italic">"{aiMessage}"</div>
             <div className="text-[8px] text-blue-600 font-bold animate-pulse">TAP SCREEN TO START</div>
          </div>
        </div>
      )}

      {/* Pause Overlay */}
      {isPaused && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/40 backdrop-blur-[1px] text-white">
          <div className="bg-yellow-400 text-black px-8 py-4 border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] font-bold text-lg animate-bounce">
            PAUSED
          </div>
          <div className="mt-4 text-[8px] font-bold drop-shadow-md">TAP TO RESUME</div>
        </div>
      )}

      {/* Game Over Overlay */}
      {isGameOver && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/70 text-white p-4 animate-in fade-in duration-300">
          <div className="text-4xl text-yellow-400 mb-6 drop-shadow-[0_4px_0_rgba(0,0,0,1)] font-bold italic tracking-tighter">CRASHED!</div>
          
          <div className="bg-white text-black p-5 border-4 border-black w-full max-w-[85%] text-center mb-6 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
            <div className="text-[7px] text-gray-400 mb-2 uppercase font-bold tracking-widest">Gemini Roast Engine</div>
            <div className="text-[10px] leading-relaxed font-bold min-h-[50px] flex items-center justify-center">
              {loadingAi ? 'CALCULATING FAIL...' : aiMessage}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 w-full px-8 mb-8">
            <div className="bg-white p-3 border-4 border-black text-center shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
              <div className="text-[8px] text-gray-400 mb-1">SCORE</div>
              <div className="text-xl text-black font-bold">{score}</div>
            </div>
            <div className="bg-yellow-400 p-3 border-4 border-black text-center shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
              <div className="text-[8px] text-gray-700 mb-1">BEST</div>
              <div className="text-xl text-black font-bold">{Math.max(score, user.highScore)}</div>
            </div>
          </div>

          <button 
            className="bg-green-500 hover:bg-green-600 text-white px-10 py-5 border-4 border-black text-[12px] font-bold shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] active:shadow-none active:translate-x-1 active:translate-y-1 transition-all"
            onPointerDown={(e) => { e.stopPropagation(); initGame(); }}
          >
            FLAP AGAIN
          </button>
        </div>
      )}
    </div>
  );
};

export default GameCanvas;
