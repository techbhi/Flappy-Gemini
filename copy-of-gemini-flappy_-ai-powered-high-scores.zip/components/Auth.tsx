
import React, { useState } from 'react';
import { User } from '../types';
import { login, register, loginAsGuest } from '../services/storageService';

interface AuthProps {
  onAuthSuccess: (user: User) => void;
}

const Auth: React.FC<AuthProps> = ({ onAuthSuccess }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (username.length < 3 || password.length < 4) {
      setError('MIN 3 CHARS NAME, 4 CHARS PASS');
      return;
    }

    if (isLogin) {
      const user = login(username, password);
      if (user) {
        onAuthSuccess(user);
      } else {
        setError('INVALID CREDENTIALS');
      }
    } else {
      const user = register(username, password);
      if (user) {
        onAuthSuccess(user);
      } else {
        setError('USER ALREADY EXISTS');
      }
    }
  };

  const handleGuest = () => {
    const guestUser = loginAsGuest();
    onAuthSuccess(guestUser);
  };

  return (
    <div className="p-8 bg-[#4ec0ca] min-h-screen md:min-h-[600px] flex flex-col items-center justify-center text-white">
      <div className="mb-8 text-center">
        <div className="text-4xl font-bold mb-2 tracking-widest drop-shadow-[4px_4px_0px_rgba(0,0,0,1)]">FLAPPY</div>
        <div className="text-2xl font-bold tracking-widest text-yellow-300 drop-shadow-[3px_3px_0px_rgba(0,0,0,1)]">GEMINI</div>
      </div>

      <form onSubmit={handleSubmit} className="w-full space-y-4 max-w-xs">
        <div>
          <label className="block text-[8px] mb-1 opacity-80">USER ID</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="w-full bg-white text-gray-800 p-3 rounded border-4 border-black text-[10px] focus:outline-none placeholder:opacity-30"
            placeholder="USERNAME"
          />
        </div>
        <div>
          <label className="block text-[8px] mb-1 opacity-80">PASSWORD</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full bg-white text-gray-800 p-3 rounded border-4 border-black text-[10px] focus:outline-none placeholder:opacity-30"
            placeholder="PASSWORD"
          />
        </div>

        {error && (
          <div className="text-red-600 bg-white p-2 text-[8px] text-center border-4 border-black font-bold">
            {error}
          </div>
        )}

        <button
          type="submit"
          className="w-full bg-yellow-400 hover:bg-yellow-500 text-black font-bold py-4 border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] active:shadow-none active:translate-x-1 active:translate-y-1 transition-all text-[10px]"
        >
          {isLogin ? 'LOG IN' : 'SIGN UP'}
        </button>
      </form>

      <div className="w-full max-w-xs mt-4">
        <div className="relative flex py-3 items-center">
          <div className="flex-grow border-t-2 border-black/20"></div>
          <span className="flex-shrink mx-4 text-[8px] text-black/40">OR</span>
          <div className="flex-grow border-t-2 border-black/20"></div>
        </div>

        <button
          onClick={handleGuest}
          className="w-full bg-white hover:bg-gray-100 text-black font-bold py-4 border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] active:shadow-none active:translate-x-1 active:translate-y-1 transition-all text-[10px]"
        >
          CONTINUE AS GUEST
        </button>
      </div>

      <button
        onClick={() => setIsLogin(!isLogin)}
        className="mt-8 text-[8px] underline hover:text-yellow-200 uppercase tracking-tighter"
      >
        {isLogin ? "NEW PLAYER? CREATE ACCOUNT" : "HAVE AN ACCOUNT? LOGIN"}
      </button>
    </div>
  );
};

export default Auth;
