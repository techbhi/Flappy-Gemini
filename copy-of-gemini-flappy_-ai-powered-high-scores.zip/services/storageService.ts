
import { User, ScoreEntry } from '../types';
import { STORAGE_KEYS } from '../constants';

const getFromStorage = <T,>(key: string): T | null => {
  const data = localStorage.getItem(key);
  return data ? JSON.parse(data) : null;
};

const saveToStorage = <T,>(key: string, data: T): void => {
  localStorage.setItem(key, JSON.stringify(data));
};

export const register = (username: string, password: string): User | null => {
  const users = getFromStorage<User[]>(STORAGE_KEYS.USERS) || [];
  if (users.find(u => u.username.toLowerCase() === username.toLowerCase())) return null;

  const newUser: User = {
    id: Math.random().toString(36).substr(2, 9),
    username,
    password,
    highScore: 0,
    isGuest: false
  };

  users.push(newUser);
  saveToStorage(STORAGE_KEYS.USERS, users);
  saveToStorage(STORAGE_KEYS.CURRENT_USER, newUser);
  return newUser;
};

export const login = (username: string, password: string): User | null => {
  const users = getFromStorage<User[]>(STORAGE_KEYS.USERS) || [];
  const user = users.find(u => u.username.toLowerCase() === username.toLowerCase() && u.password === password);
  if (user) {
    saveToStorage(STORAGE_KEYS.CURRENT_USER, user);
    return user;
  }
  return null;
};

export const loginAsGuest = (): User => {
  // Check if there's an existing guest session
  const existingSession = getCurrentUser();
  if (existingSession && existingSession.isGuest) {
    return existingSession;
  }

  const guestId = Math.floor(1000 + Math.random() * 9000);
  const guestUser: User = {
    id: `guest-${guestId}`,
    username: `GUEST_${guestId}`,
    highScore: 0,
    isGuest: true
  };

  // We don't necessarily need to save guests to the global USERS list 
  // until they have a high score, but we save them to the current session.
  saveToStorage(STORAGE_KEYS.CURRENT_USER, guestUser);
  return guestUser;
};

export const getCurrentUser = (): User | null => {
  return getFromStorage<User>(STORAGE_KEYS.CURRENT_USER);
};

export const logout = (): void => {
  localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
};

export const updateHighScore = (username: string, score: number): void => {
  const users = getFromStorage<User[]>(STORAGE_KEYS.USERS) || [];
  const userIdx = users.findIndex(u => u.username.toLowerCase() === username.toLowerCase());
  
  const currentUser = getCurrentUser();
  
  if (userIdx !== -1) {
    // Registered User Update
    if (score > users[userIdx].highScore) {
      users[userIdx].highScore = score;
      saveToStorage(STORAGE_KEYS.USERS, users);
      
      if (currentUser && currentUser.username.toLowerCase() === username.toLowerCase()) {
        currentUser.highScore = score;
        saveToStorage(STORAGE_KEYS.CURRENT_USER, currentUser);
      }
    }
  } else if (currentUser && currentUser.isGuest && currentUser.username === username) {
    // Guest User Update
    if (score > currentUser.highScore) {
      currentUser.highScore = score;
      saveToStorage(STORAGE_KEYS.CURRENT_USER, currentUser);
    }
  }

  // Update Global Leaderboard
  const leaderboard = getFromStorage<ScoreEntry[]>(STORAGE_KEYS.LEADERBOARD) || [];
  const existingEntryIdx = leaderboard.findIndex(e => e.username.toLowerCase() === username.toLowerCase());
  
  if (existingEntryIdx !== -1) {
    if (score > leaderboard[existingEntryIdx].score) {
      leaderboard[existingEntryIdx] = {
        username,
        score,
        date: new Date().toLocaleDateString()
      };
    }
  } else {
    leaderboard.push({
      username,
      score,
      date: new Date().toLocaleDateString()
    });
  }

  leaderboard.sort((a, b) => b.score - a.score);
  saveToStorage(STORAGE_KEYS.LEADERBOARD, leaderboard.slice(0, 10));
};

export const getLeaderboard = (): ScoreEntry[] => {
  return getFromStorage<ScoreEntry[]>(STORAGE_KEYS.LEADERBOARD) || [];
};
