
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getGeminiMessage = async (score: number, username: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `User ${username} just scored ${score} in a Flappy Bird game. 
      Generate a short, snarky but funny motivational quote (max 15 words) in a retro gamer style. 
      If the score is 0, make it a bit of a roast. 
      If the score is over 20, make it impressed.`,
      config: {
        temperature: 0.9,
        topP: 0.95,
      }
    });

    return response.text?.trim().toUpperCase() || "GAME OVER! TRY AGAIN!";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "GRAVITY IS A CRUEL MISTRESS!";
  }
};
